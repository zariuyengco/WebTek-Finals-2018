<?php
include 'maintenance.php';
$get_name = $var2;


    $servername = "localhost";
    $username = "root";
    $password = "";
    $DB = "cargo_database";

    //to create a connection
    $conn = mysqli_connect($servername, $username, $password, $DB);
      if (!$conn){
          die("Couldn't connect to SQL Server on $server");
      }


    //to check the connection
   // if($cargo_db->connection_error){
      //die("Connection failed: " . $cargo_db->connect_error);
  //  }

$sql = "UPDATE users SET status ='1' WHERE userID = '$var2' ";

mysqli_query($conn, $sql);
echo "<script> window.location='request.php'</script>";
mysqli_close($conn);
?>
